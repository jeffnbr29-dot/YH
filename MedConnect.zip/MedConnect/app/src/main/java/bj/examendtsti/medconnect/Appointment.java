package bj.examendtsti.medconnect;

public class Appointment {
    private int id;
    private String doctorName;
    private String specialty;
    private String date;
    private String time;
    private String status;

    public Appointment(int id, String doctorName, String specialty, String date, String time, String status) {
        this.id = id;
        this.doctorName = doctorName;
        this.specialty = specialty;
        this.date = date;
        this.time = time;
        this.status = status;
    }

    public int getId() {
        return id;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public String getSpecialty() {
        return specialty;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getStatus() {
        return status;
    }
}

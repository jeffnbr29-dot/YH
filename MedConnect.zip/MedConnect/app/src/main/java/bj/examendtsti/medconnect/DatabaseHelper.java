package bj.examendtsti.medconnect;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "MedConnect.db";
    private static final int DATABASE_VERSION = 1;

    public static final String TABLE_MEDECINS = "medecins";
    public static final String COL_MED_ID = "id_medecin";
    public static final String COL_MED_NOM = "nom";
    public static final String COL_MED_PRENOM = "prenom";
    public static final String COL_MED_SPECIALITE = "specialite";
    public static final String COL_MED_TELEPHONE = "telephone";
    public static final String COL_MED_EMAIL = "email";


    public static final String TABLE_PATIENTS = "patients";
    public static final String COL_PAT_ID = "id_patient";
    public static final String COL_PAT_NOM = "nom";
    public static final String COL_PAT_PRENOM = "prenom";
    public static final String COL_PAT_EMAIL = "email";
    public static final String COL_PAT_TELEPHONE = "telephone";
    public static final String COL_PAT_PASSWORD = "mot_de_passe";

    public static final String TABLE_RENDEZ_VOUS = "rendez_vous";
    public static final String COL_RDV_ID = "id";
    public static final String COL_RDV_MED_ID = "id_medecin";
    public static final String COL_RDV_PAT_ID = "id_patient";
    public static final String COL_RDV_DATE = "date";
    public static final String COL_RDV_HEURE = "heure";
    public static final String COL_RDV_STATUT = "statut";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createMedecinsTable = "CREATE TABLE " + TABLE_MEDECINS + " (" +
                COL_MED_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_MED_NOM + " TEXT, " +
                COL_MED_PRENOM + " TEXT, " +
                COL_MED_SPECIALITE + " TEXT, " +
                COL_MED_TELEPHONE + " TEXT, " +
                COL_MED_EMAIL + " TEXT)";
        db.execSQL(createMedecinsTable);

        String createPatientsTable = "CREATE TABLE " + TABLE_PATIENTS + " (" +
                COL_PAT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_PAT_NOM + " TEXT, " +
                COL_PAT_PRENOM + " TEXT, " +
                COL_PAT_EMAIL + " TEXT UNIQUE, " +
                COL_PAT_TELEPHONE + " TEXT, " +
                COL_PAT_PASSWORD + " TEXT)";
        db.execSQL(createPatientsTable);

        String createRdvTable = "CREATE TABLE " + TABLE_RENDEZ_VOUS + " (" +
                COL_RDV_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_RDV_MED_ID + " INTEGER, " +
                COL_RDV_PAT_ID + " INTEGER, " +
                COL_RDV_DATE + " TEXT, " +
                COL_RDV_HEURE + " TEXT, " +
                COL_RDV_STATUT + " TEXT, " +
                "FOREIGN KEY(" + COL_RDV_MED_ID + ") REFERENCES " + TABLE_MEDECINS + "(" + COL_MED_ID + "), " +
                "FOREIGN KEY(" + COL_RDV_PAT_ID + ") REFERENCES " + TABLE_PATIENTS + "(" + COL_PAT_ID + "))";
        db.execSQL(createRdvTable);

        seedDoctors(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RENDEZ_VOUS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PATIENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MEDECINS);
        onCreate(db);
    }

    private void seedDoctors(SQLiteDatabase db) {
        insertDoctor(db, "Dupont", "", "", "", "");
        insertDoctor(db, "Martin", "", "", "", "");
        insertDoctor(db, "Ali", "", "", "", "");
    }

    private void insertDoctor(SQLiteDatabase db, String nom, String prenom, String specialite, String telephone, String email) {
        ContentValues values = new ContentValues();
        values.put(COL_MED_NOM, nom);
        values.put(COL_MED_PRENOM, prenom);
        values.put(COL_MED_SPECIALITE, specialite);
        values.put(COL_MED_TELEPHONE, telephone);
        values.put(COL_MED_EMAIL, email);
        db.insert(TABLE_MEDECINS, null, values);
    }

    public boolean registerPatient(String nom, String email, String telephone, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_PAT_NOM, nom);
        values.put(COL_PAT_PRENOM, ""); // optional
        values.put(COL_PAT_EMAIL, email);
        values.put(COL_PAT_TELEPHONE, telephone);
        values.put(COL_PAT_PASSWORD, password);

        long result = db.insert(TABLE_PATIENTS, null, values);
        return result != -1;
    }

    public Cursor authenticatePatient(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_PATIENTS + " WHERE " +
                COL_PAT_EMAIL + " = ? AND " + COL_PAT_PASSWORD + " = ?";
        return db.rawQuery(query, new String[]{email, password});
    }

    public Cursor getAllDoctors() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_MEDECINS, null);
    }

    public Cursor getDoctorById(int idMedecin) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_MEDECINS + " WHERE " + COL_MED_ID + " = ?", new String[]{String.valueOf(idMedecin)});
    }

    public boolean bookAppointment(int idMedecin, int idPatient, String date, String heure) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_RDV_MED_ID, idMedecin);
        values.put(COL_RDV_PAT_ID, idPatient);
        values.put(COL_RDV_DATE, date);
        values.put(COL_RDV_HEURE, heure);
        values.put(COL_RDV_STATUT, "Confirmé");

        long result = db.insert(TABLE_RENDEZ_VOUS, null, values);
        return result != -1;
    }

    public Cursor getPatientAppointments(int idPatient) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT r." + COL_RDV_ID + ", r." + COL_RDV_DATE + ", r." + COL_RDV_HEURE + ", r." + COL_RDV_STATUT +
                ", m." + COL_MED_NOM + ", m." + COL_MED_PRENOM + ", m." + COL_MED_SPECIALITE +
                " FROM " + TABLE_RENDEZ_VOUS + " r" +
                " JOIN " + TABLE_MEDECINS + " m ON r." + COL_RDV_MED_ID + " = m." + COL_MED_ID +
                " WHERE r." + COL_RDV_PAT_ID + " = ?" +
                " ORDER BY r." + COL_RDV_ID + " DESC";
        return db.rawQuery(query, new String[]{String.valueOf(idPatient)});
    }
}

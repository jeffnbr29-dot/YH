package bj.examendtsti.medconnect;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {

    private RecyclerView recyclerViewHistory;
    private TextView tvEmptyHistory;
    private TextView btnBack;

    private DatabaseHelper dbHelper;
    private SharedPreferences sharedPreferences;
    private List<Appointment> appointmentList;
    private AppointmentAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        dbHelper = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences("MedConnectSession", Context.MODE_PRIVATE);

        if (!sharedPreferences.contains("patient_id")) {
            Intent intent = new Intent(HistoryActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        recyclerViewHistory = findViewById(R.id.recyclerViewHistory);
        tvEmptyHistory = findViewById(R.id.tvEmptyHistory);
        btnBack = findViewById(R.id.btnBack);

        recyclerViewHistory.setLayoutManager(new LinearLayoutManager(this));
        appointmentList = new ArrayList<>();

        loadAppointments();

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void loadAppointments() {
        int patientId = sharedPreferences.getInt("patient_id", -1);
        appointmentList.clear();

        Cursor cursor = dbHelper.getPatientAppointments(patientId);
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int idCol = cursor.getColumnIndex(DatabaseHelper.COL_RDV_ID);
                int dateCol = cursor.getColumnIndex(DatabaseHelper.COL_RDV_DATE);
                int heureCol = cursor.getColumnIndex(DatabaseHelper.COL_RDV_HEURE);
                int statutCol = cursor.getColumnIndex(DatabaseHelper.COL_RDV_STATUT);
                int medNomCol = cursor.getColumnIndex(DatabaseHelper.COL_MED_NOM);
                int medPrenomCol = cursor.getColumnIndex(DatabaseHelper.COL_MED_PRENOM);
                int medSpecCol = cursor.getColumnIndex(DatabaseHelper.COL_MED_SPECIALITE);

                if (idCol != -1 && dateCol != -1 && heureCol != -1 && statutCol != -1 && medNomCol != -1 && medPrenomCol != -1 && medSpecCol != -1) {
                    int id = cursor.getInt(idCol);
                    String date = cursor.getString(dateCol);
                    String heure = cursor.getString(heureCol);
                    String statut = cursor.getString(statutCol);
                    String medNom = cursor.getString(medNomCol);
                    String medPrenom = cursor.getString(medPrenomCol);
                    String medSpec = cursor.getString(medSpecCol);

                    Appointment appointment = new Appointment(
                            id,
                            "Dr. " + medNom + " " + medPrenom,
                            medSpec,
                            date,
                            heure,
                            statut
                    );
                    appointmentList.add(appointment);
                }
            }
            cursor.close();
        }

        if (appointmentList.isEmpty()) {
            tvEmptyHistory.setVisibility(View.VISIBLE);
            recyclerViewHistory.setVisibility(View.GONE);
        } else {
            tvEmptyHistory.setVisibility(View.GONE);
            recyclerViewHistory.setVisibility(View.VISIBLE);
            adapter = new AppointmentAdapter(appointmentList);
            recyclerViewHistory.setAdapter(adapter);
        }
    }
}

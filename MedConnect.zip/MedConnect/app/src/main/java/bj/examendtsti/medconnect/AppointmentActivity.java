package bj.examendtsti.medconnect;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class AppointmentActivity extends AppCompatActivity {

    private Spinner spinnerDoctors;
    private EditText etDate, etTime;
    private Button btnSubmit;
    private TextView btnBack;

    private DatabaseHelper dbHelper;
    private SharedPreferences sharedPreferences;
    private List<Integer> doctorIdsList;
    private List<String> doctorNamesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

        dbHelper = new DatabaseHelper(this);
        sharedPreferences = getSharedPreferences("MedConnectSession", Context.MODE_PRIVATE);

        if (!sharedPreferences.contains("patient_id")) {
            Intent intent = new Intent(AppointmentActivity.this, LoginActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        spinnerDoctors = findViewById(R.id.spinnerDoctors);
        etDate = findViewById(R.id.etDate);
        etTime = findViewById(R.id.etTime);
        btnSubmit = findViewById(R.id.btnSubmit);
        btnBack = findViewById(R.id.btnBack);

        doctorIdsList = new ArrayList<>();
        doctorNamesList = new ArrayList<>();

        loadDoctors();

        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });

        etTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePicker();
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedPosition = spinnerDoctors.getSelectedItemPosition();
                if (selectedPosition == Spinner.INVALID_POSITION || doctorIdsList.isEmpty()) {
                    Toast.makeText(AppointmentActivity.this, "Veuillez choisir un médecin", Toast.LENGTH_SHORT).show();
                    return;
                }

                String dateStr = etDate.getText().toString().trim();
                String timeStr = etTime.getText().toString().trim();

                if (dateStr.isEmpty() || timeStr.isEmpty()) {
                    Toast.makeText(AppointmentActivity.this, "Veuillez sélectionner la date et l'heure", Toast.LENGTH_SHORT).show();
                    return;
                }

                int patientId = sharedPreferences.getInt("patient_id", -1);
                int doctorId = doctorIdsList.get(selectedPosition);

                boolean success = dbHelper.bookAppointment(doctorId, patientId, dateStr, timeStr);
                if (success) {
                    Toast.makeText(AppointmentActivity.this, "Rendez-vous enregistré avec succès !", Toast.LENGTH_LONG).show();
                    finish();
                } else {
                    Toast.makeText(AppointmentActivity.this, "Erreur lors de l'enregistrement", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void loadDoctors() {
        Cursor cursor = dbHelper.getAllDoctors();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                int idCol = cursor.getColumnIndex(DatabaseHelper.COL_MED_ID);
                int nomCol = cursor.getColumnIndex(DatabaseHelper.COL_MED_NOM);
                int prenomCol = cursor.getColumnIndex(DatabaseHelper.COL_MED_PRENOM);
                int specCol = cursor.getColumnIndex(DatabaseHelper.COL_MED_SPECIALITE);

                if (idCol != -1 && nomCol != -1 && prenomCol != -1 && specCol != -1) {
                    int id = cursor.getInt(idCol);
                    String nom = cursor.getString(nomCol);
                    String prenom = cursor.getString(prenomCol);
                    String spec = cursor.getString(specCol);

                    doctorIdsList.add(id);
                    doctorNamesList.add("Dr. " + nom + " " + prenom + " (" + spec + ")");
                }
            }
            cursor.close();
        }

        if (doctorNamesList.isEmpty()) {
            doctorNamesList.add("Aucun médecin disponible");
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, doctorNamesList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDoctors.setAdapter(adapter);
    }

    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        String formattedDay = dayOfMonth < 10 ? "0" + dayOfMonth : String.valueOf(dayOfMonth);
                        String formattedMonth = (monthOfYear + 1) < 10 ? "0" + (monthOfYear + 1) : String.valueOf(monthOfYear + 1);
                        etDate.setText(formattedDay + "/" + formattedMonth + "/" + year);
                    }
                }, year, month, day);
        datePickerDialog.show();
    }

    private void showTimePicker() {
        final Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        String formattedHour = hourOfDay < 10 ? "0" + hourOfDay : String.valueOf(hourOfDay);
                        String formattedMinute = minute < 10 ? "0" + minute : String.valueOf(minute);
                        etTime.setText(formattedHour + ":" + formattedMinute);
                    }
                }, hour, minute, true);
        timePickerDialog.show();
    }
}

<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: connexion.php");
    exit();
}

$serveur = "localhost";
$utilisateur = "root";
$mot_de_passe = "";
$base = "ES_bd";

$cnx = mysqli_connect($serveur, $utilisateur, $mot_de_passe, $base);

if (!$cnx) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

mysqli_set_charset($cnx, "utf8mb4");

$eleve_trouve = null;
$note_trouvee = null;
$aucun_resultat = false;

if (isset($_POST['rechercher'])) {
    $matricule = $_POST['matricule'];

    $sql_eleve = "SELECT * FROM eleves WHERE matricule = '$matricule'";
    $res_eleve = mysqli_query($cnx, $sql_eleve);

    if (mysqli_num_rows($res_eleve) == 1) {
        $eleve_trouve = mysqli_fetch_assoc($res_eleve);

        $sql_note = "SELECT * FROM note WHERE eleve_id = '" . $eleve_trouve['Id_eleve'] . "' ORDER BY Id_notes DESC LIMIT 1";
        $res_note = mysqli_query($cnx, $sql_note);

        if (mysqli_num_rows($res_note) == 1) {
            $note_trouvee = mysqli_fetch_assoc($res_note);
        }
    } else {
        $aucun_resultat = true;
    }
}

if (isset($note_trouvee['moyenne'])) {
    $moyenne = $note_trouvee['moyenne'];

    if ($moyenne >= 18) {
        $appreciation = "Excellent";
    } elseif ($moyenne >= 16) {
        $appreciation = "Très bien";
    } elseif ($moyenne >= 14) {
        $appreciation = "Bien";
    } elseif ($moyenne >= 12) {
        $appreciation = "Assez bien";
    } elseif ($moyenne >= 10) {
        $appreciation = "Passable";
    } else {
        $appreciation = "Insuffisant";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Résultats - Étoile du Savoir</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="conteneur">

    <div class="menu_lateral">
        <div class="logo_zone">
            <img src="img/logo.png" alt="Logo">
            <h1>ÉTOILE DU SAVOIR</h1>
            <p>Système de gestion scolaire</p>
        </div>
        <ul>
            <li><a href="accueil.php">Accueil</a></li>
            <li><a href="eleve.php">Elèves</a></li>
            <li><a href="note.php">Notes</a></li>
            <li><a href="resultats.php" class="actif">Résultat</a></li>
        </ul>
    </div>

    <div class="contenu_principal">

        <div class="barre_titre">
            <h2>Résultats de l'élève</h2>
        </div>

        <div class="zone_page">

            <div class="boite_resultat">

                <form method="post" action="resultats.php">
                    <div class="zone_recherche">
                        <input type="text" name="matricule" placeholder="Saisissez le matricule de l'élève" required>
                        <br>
                        <input type="submit" name="rechercher" value="Rechercher les notes">
                    </div>
                </form>

                <?php if ($aucun_resultat) { ?>
                    <p style="text-align:center; color:#ff5555;">Aucun élève trouvé avec ce matricule.</p>
                <?php } ?>

                <?php if ($eleve_trouve != null) { ?>
                    <div class="details_resultat">
                        <?php if ($note_trouvee != null) { ?>
                            <p>Moyenne générale — <?php echo $note_trouvee['trimestre']; ?></p>
                        <?php } ?>
                        <p>Matricule : <?php echo $eleve_trouve['matricule']; ?></p>
                        <p class="nom_eleve">
                            <?php echo $eleve_trouve['nom'] . " " . $eleve_trouve['prenom']; ?>
                            &nbsp;&nbsp;&nbsp;Sexe: <?php echo $eleve_trouve['sexe']; ?>
                        </p>

                        <?php if ($note_trouvee != null) { ?>
                            <p class="appreciation">
                                Appréciation :
                                <?php echo $note_trouvee['moyenne']; ?> / 20 - <?php echo $appreciation; ?>
                            </p>
                        <?php } else { ?>
                            <p>Aucune note enregistrée pour cet élève.</p>
                        <?php } ?>
                    </div>
                <?php } ?>

            </div>

        </div>

    </div>

</div>

<div class="copyright">Copyright 2026 Ecole du savoir- Parakou, Bénin</div>

</body>
</html>

<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: connexion.php");
    exit();
}

$serveur = "localhost";
$utilisateur = "root";
$mot_de_passe = "";
$base = "ES_bd";

$cnx = mysqli_connect($serveur, $utilisateur, $mot_de_passe, $base);

if (!$cnx) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

mysqli_set_charset($cnx, "utf8mb4");

$annee_courante = date("y");

$sql_dernier = "SELECT matricule FROM eleves ORDER BY Id_eleve DESC LIMIT 1";
$res_dernier = mysqli_query($cnx, $sql_dernier);

if (mysqli_num_rows($res_dernier) > 0) {
    $ligne_dernier = mysqli_fetch_assoc($res_dernier);
    $prefixe_annee = substr($ligne_dernier['matricule'], 3, 2);
    $dernier_numero = (int) substr($ligne_dernier['matricule'], -3);
    $nouveau_numero = $dernier_numero + 1;
} else {
    $prefixe_annee = $annee_courante;
    $nouveau_numero = 1;
}

$nouveau_matricule = "ES-" . $prefixe_annee . str_pad($nouveau_numero, 3, "0", STR_PAD_LEFT);

if (isset($_POST['valider'])) {
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $date_naissance = $_POST['date_naissance'];
    $sexe = $_POST['sexe'];
    $classe = $_POST['classe'];
    $matricule = $_POST['matricule'];

    $sql_insert = "INSERT INTO eleves (matricule, nom, prenom, date_naissance, sexe, classe)
                    VALUES ('$matricule', '$nom', '$prenom', '$date_naissance', '$sexe', '$classe')";
    mysqli_query($cnx, $sql_insert);

    header("Location: eleve.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Elèves - Étoile du Savoir</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="conteneur">

    <div class="menu_lateral">
        <div class="logo_zone">
            <img src="img/logo.png" alt="Logo">
            <h1>ÉTOILE DU SAVOIR</h1>
            <p>Système de gestion scolaire</p>
        </div>
        <ul>
            <li><a href="accueil.php">Accueil</a></li>
            <li><a href="eleve.php" class="actif">Elèves</a></li>
            <li><a href="note.php">Notes</a></li>
            <li><a href="resultats.php">Résultat</a></li>
        </ul>
    </div>

    <div class="contenu_principal">

        <div class="barre_titre">
            <h2>Tableau de bord</h2>
        </div>

        <div class="zone_page">

            <h3>Inscrire un élève</h3>

            <div class="boite_formulaire">

                <div class="info_auto">
                    Matricule généré automatiquement<br>
                    <?php echo $nouveau_matricule; ?>
                </div>

                <form method="post" action="eleve.php">
                    <input type="hidden" name="matricule" value="<?php echo $nouveau_matricule; ?>">

                    <div class="ligne_form">
                        <div class="champ_form">
                            <label>Nom</label>
                            <input type="text" name="nom" required>
                        </div>
                        <div class="champ_form">
                            <label>Date de naissance</label>
                            <input type="date" name="date_naissance" required>
                        </div>
                    </div>

                    <div class="ligne_form">
                        <div class="champ_form">
                            <label>Prénoms</label>
                            <input type="text" name="prenom" required>
                        </div>
                        <div class="champ_form">
                            <label>Sexe</label>
                            <select name="sexe">
                                <option value="Masculin">Masculin</option>
                                <option value="Féminin">Féminin</option>
                            </select>
                        </div>
                    </div>

                    <div class="ligne_form">
                        <div class="champ_form">
                            <label>Classe</label>
                            <select name="classe" required>
                                <option value="">Sélectionner</option>
                                <option value="CI">CI</option>
                                <option value="CP">CP</option>
                                <option value="CE1">CE1</option>
                                <option value="CE2">CE2</option>
                                <option value="CM1">CM1</option>
                                <option value="CM2">CM2</option>
                            </select>
                        </div>
                    </div>

                    <input type="submit" name="valider" class="bouton_principal" value="Enrégistrer l'élève">
                </form>

            </div>

        </div>

    </div>

</div>

<div class="copyright">Copyright 2026 Ecole du savoir- Parakou, Bénin</div>

</body>
</html>

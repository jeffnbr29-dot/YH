<?php
session_start();

$serveur = "localhost";
$utilisateur = "root";
$mot_de_passe = "";
$base = "ES_bd";

$cnx = mysqli_connect($serveur, $utilisateur, $mot_de_passe, $base);

if (!$cnx) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

mysqli_set_charset($cnx, "utf8mb4");

$erreur = "";

if (isset($_POST['valider'])) {
    $login = $_POST['login'];
    $mdp = $_POST['mot_de_passe'];

    $sql = "SELECT * FROM users WHERE login = '$login' AND mot_de_passe = '$mdp'";
    $resultat = mysqli_query($cnx, $sql);

    if (mysqli_num_rows($resultat) == 1) {
        $ligne = mysqli_fetch_assoc($resultat);
        $_SESSION['login'] = $ligne['login'];
        $_SESSION['id_user'] = $ligne['Id_user'];
        header("Location: accueil.php");
        exit();
    } else {
        $erreur = "Identifiant ou mot de passe incorrect.";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Étoile du Savoir</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="entete-connexion">
        <img src="img/logo.png" alt="Logo">
        <h1>ÉTOILE DU SAVOIR</h1>
        <p>Système de gestion scolaire</p>
    </div>

    <div class="boite-connexion">
        <h2>Connexion à l'application</h2>

        <?php if ($erreur != "") { ?>
            <div class="message_erreur"><?php echo $erreur; ?></div>
        <?php } ?>

        <form method="post" action="connexion.php">
            <label for="login">Identifiant</label>
            <input type="text" name="login" id="login" required>

            <label for="mot_de_passe">Mot de passe</label>
            <input type="password" name="mot_de_passe" id="mot_de_passe" required>

            <input type="submit" name="valider" value="Se connecter">
        </form>
    </div>

    <div class="copyright">Copyright 2026  Ecole du savoir-Parakou, Bénin</div>

</body>
</html>

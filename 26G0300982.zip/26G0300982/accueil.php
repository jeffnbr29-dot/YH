<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: connexion.php");
    exit();
}

$serveur = "localhost";
$utilisateur = "root";
$mot_de_passe = "";
$base = "ES_bd";

$cnx = mysqli_connect($serveur, $utilisateur, $mot_de_passe, $base);

if (!$cnx) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

mysqli_set_charset($cnx, "utf8mb4");

$sql_nb_eleves = "SELECT COUNT(*) AS total FROM eleves";
$res_nb_eleves = mysqli_query($cnx, $sql_nb_eleves);
$ligne_nb_eleves = mysqli_fetch_assoc($res_nb_eleves);
$nb_eleves = $ligne_nb_eleves['total'];

$sql_nb_notes = "SELECT COUNT(*) AS total FROM note";
$res_nb_notes = mysqli_query($cnx, $sql_nb_notes);
$ligne_nb_notes = mysqli_fetch_assoc($res_nb_notes);
$nb_notes = $ligne_nb_notes['total'];

$sql_nb_classes = "SELECT COUNT(DISTINCT classe) AS total FROM eleves";
$res_nb_classes = mysqli_query($cnx, $sql_nb_classes);
$ligne_nb_classes = mysqli_fetch_assoc($res_nb_classes);
$nb_classes = $ligne_nb_classes['total'];

$sql_eleves = "SELECT * FROM eleves ORDER BY Id_eleve ASC";
$res_eleves = mysqli_query($cnx, $sql_eleves);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil - Étoile du Savoir</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="conteneur">

    <div class="menu_lateral">
        <div class="logo_zone">
            <img src="img/logo.png" alt="Logo">
            <h1>ÉTOILE DU SAVOIR</h1>
            <p>Système de gestion scolaire</p>
        </div>
        <ul>
            <li><a href="accueil.php" class="actif">Accueil</a></li>
            <li><a href="eleve.php">Elèves</a></li>
            <li><a href="note.php">Notes</a></li>
            <li><a href="resultats.php">Résultat</a></li>
        </ul>
    </div>

    <div class="contenu_principal">

        <div class="barre_titre">
            <h2>Tableau de bord</h2>
        </div>

        <div class="zone_page">

            <h3>Statistiques</h3>

            <div class="blocs_stats">
                <div class="bloc_stat">
                    <div class="chiffre"><?php echo $nb_eleves; ?></div>
                    <div class="libelle">Elèves inscrits</div>
                </div>
                <div class="bloc_stat">
                    <div class="chiffre"><?php echo $nb_classes; ?></div>
                    <div class="libelle">Classes actives</div>
                </div>
                <div class="bloc_stat">
                    <div class="chiffre"><?php echo $nb_notes; ?></div>
                    <div class="libelle">Notes enregistrées</div>
                </div>
            </div>

            <h3 style="margin-top:35px;">Listes des Apprenants</h3>

            <table class="tableau_donnees">
                <tr>
                    <th>Matricule</th>
                    <th>Nom complet</th>
                    <th>Classe</th>
                    <th>Sexe</th>
                    <th>Date de naissance</th>
                </tr>
                <?php while ($eleve = mysqli_fetch_assoc($res_eleves)) { ?>
                <tr>
                    <td><?php echo $eleve['matricule']; ?></td>
                    <td><?php echo $eleve['nom'] . " " . $eleve['prenom']; ?></td>
                    <td><?php echo $eleve['classe']; ?></td>
                    <td><?php echo $eleve['sexe']; ?></td>
                    <td><?php echo date("d/m/Y", strtotime($eleve['date_naissance'])); ?></td>
                </tr>
                <?php } ?>
            </table>

        </div>

    </div>

</div>

<div class="copyright">Copyright 2026 Ecole du savoir- Parakou, Bénin</div>

</body>
</html>

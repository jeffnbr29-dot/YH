-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : lun. 22 juin 2026 à 10:59
-- Version du serveur :  5.7.31
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `es_bd`
--

-- --------------------------------------------------------

--
-- Structure de la table `eleves`
--

DROP TABLE IF EXISTS `eleves`;
CREATE TABLE IF NOT EXISTS `eleves` (
  `Id_eleve` int(11) NOT NULL AUTO_INCREMENT,
  `matricule` varchar(20) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `date_naissance` date NOT NULL,
  `sexe` varchar(10) NOT NULL,
  `classe` varchar(10) NOT NULL,
  PRIMARY KEY (`Id_eleve`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `eleves`
--

INSERT INTO `eleves` (`Id_eleve`, `matricule`, `nom`, `prenom`, `date_naissance`, `sexe`, `classe`) VALUES
(1, 'ES-25001', 'HODJO', 'Rachelle', '2026-03-03', 'Féminin', 'CM2'),
(2, 'ES-25002', 'HOUE', 'Jean', '2026-03-03', 'Masculin', 'CM1'),
(3, 'ES-25003', 'OHO', 'Rachelle', '2026-03-03', 'Féminin', 'CM2'),
(4, 'ES-25004', 'HOUENOU', 'Adèle', '2026-03-03', 'Féminin', 'CM1');

-- --------------------------------------------------------

--
-- Structure de la table `note`
--

DROP TABLE IF EXISTS `note`;
CREATE TABLE IF NOT EXISTS `note` (
  `Id_notes` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `trimestre` varchar(20) NOT NULL,
  `maths` decimal(5,2) NOT NULL,
  `communication_lecture` decimal(5,2) NOT NULL,
  `ES` decimal(5,2) NOT NULL,
  `moyenne` decimal(5,2) NOT NULL,
  PRIMARY KEY (`Id_notes`),
  KEY `eleve_id` (`eleve_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `note`
--

INSERT INTO `note` (`Id_notes`, `eleve_id`, `trimestre`, `maths`, `communication_lecture`, `ES`, `moyenne`) VALUES
(1, 1, 'Trimestre 1', '12.00', '13.00', '9.00', '11.33'),
(2, 2, 'Trimestre 1', '20.00', '18.00', '14.00', '17.33'),
(3, 4, 'Trimestre 1', '20.00', '18.00', '19.00', '19.00'),
(4, 5, 'Trimestre 1', '9.00', '17.00', '6.00', '10.67'),
(5, 1, 'Trimestre 2', '12.00', '20.00', '19.00', '17.00');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `Id_user` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(50) NOT NULL,
  `mot_de_passe` varchar(50) NOT NULL,
  PRIMARY KEY (`Id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`Id_user`, `login`, `mot_de_passe`) VALUES
(1, 'admin', 'admin1234');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

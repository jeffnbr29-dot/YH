<?php
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: connexion.php");
    exit();
}

$serveur = "localhost";
$utilisateur = "root";
$mot_de_passe = "";
$base = "ES_bd";

$cnx = mysqli_connect($serveur, $utilisateur, $mot_de_passe, $base);

if (!$cnx) {
    die("Erreur de connexion à la base de données : " . mysqli_connect_error());
}

mysqli_set_charset($cnx, "utf8mb4");

$message = "";

if (isset($_POST['valider'])) {
    $eleve_id = $_POST['eleve_id'];
    $trimestre = $_POST['trimestre'];
    $maths = $_POST['maths'];
    $communication_lecture = $_POST['communication_lecture'];
    $es = $_POST['es'];
    $moyenne = ($maths + $communication_lecture + $es) / 3;
    $moyenne = round($moyenne, 2);

    $sql_insert = "INSERT INTO note (eleve_id, trimestre, maths, communication_lecture, ES, moyenne)
                    VALUES ('$eleve_id', '$trimestre', '$maths', '$communication_lecture', '$es', '$moyenne')";
    mysqli_query($cnx, $sql_insert);

    $message = "Notes enregistrées avec succès. Moyenne obtenue : $moyenne / 20";
}

$sql_eleves = "SELECT * FROM eleves ORDER BY nom ASC";
$res_eleves = mysqli_query($cnx, $sql_eleves);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notes - Étoile du Savoir</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="conteneur">

    <div class="menu_lateral">
        <div class="logo_zone">
            <img src="img/logo.png" alt="Logo">
            <h1>ÉTOILE DU SAVOIR</h1>
            <p>Système de gestion scolaire</p>
        </div>
        <ul>
            <li><a href="accueil.php">Accueil</a></li>
            <li><a href="eleve.php">Elèves</a></li>
            <li><a href="note.php" class="actif">Notes</a></li>
            <li><a href="resultats.php">Résultat</a></li>
        </ul>
    </div>

    <div class="contenu_principal">

        <div class="barre_titre">
            <h2>Saisie des notes</h2>
        </div>

        <div class="zone_page">

            <div class="boite_formulaire">

                <?php if ($message != "") { ?>
                    <div class="info_auto"><?php echo $message; ?></div>
                <?php } ?>

                <form method="post" action="note.php">

                    <div class="ligne_form">
                        <label>Sélectionner l'élève</label><br>
                        <select name="eleve_id" required style="width:100%; padding:10px 14px; border:none; border-radius:8px; font-size:14px; background-color:#ffffff; color:#000000;">
                            <option value="">Sélectionner</option>
                            <?php while ($eleve = mysqli_fetch_assoc($res_eleves)) { ?>
                            <option value="<?php echo $eleve['Id_eleve']; ?>">
                                <?php echo $eleve['matricule'] . " - " . $eleve['nom'] . " " . $eleve['prenom']; ?>
                            </option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="ligne_form">
                        <label>Sélectionner le trimestre</label><br>
                        <select name="trimestre" required style="width:100%; padding:10px 14px; border:none; border-radius:8px; font-size:14px; background-color:#ffffff; color:#000000;">
                            <option value="Trimestre 1">Trimestre 1</option>
                            <option value="Trimestre 2">Trimestre 2</option>
                            <option value="Trimestre 3">Trimestre 3</option>
                        </select>
                    </div>

                    <label>Note /20</label>

                    <div class="blocs_notes">
                        <div class="bloc_note">
                            <label>Mathématique</label>
                            <input type="number" step="0.25" min="0" max="20" name="maths" id="maths" required>
                        </div>
                        <div class="bloc_note">
                            <label>Communication et lecture</label>
                            <input type="number" step="0.25" min="0" max="20" name="communication_lecture" id="communication_lecture" required>
                        </div>
                        <div class="bloc_note">
                            <label>ES</label>
                            <input type="number" step="0.25" min="0" max="20" name="es" id="es" required>
                        </div>
                    </div>

                    <input type="button" class="bouton_principal" value="Moyenne du trimestre" onclick="calculerMoyenne()">

                    <div class="moyenne_resultat" id="zone_moyenne">Moyenne calculée :</div>

                    <input type="submit" name="valider" class="bouton_principal" value="Enregistrer les notes">

                </form>

            </div>

        </div>

    </div>

</div>

<div class="copyright">Copyright 2026 Ecole du savoir- Parakou, Bénin</div>

<script>
function calculerMoyenne() {
    var maths = parseFloat(document.getElementById("maths").value) || 0;
    var communication = parseFloat(document.getElementById("communication_lecture").value) || 0;
    var es = parseFloat(document.getElementById("es").value) || 0;

    var moyenne = (maths + communication + es) / 3;
    moyenne = Math.round(moyenne * 100) / 100;

    var appreciation = "";
    if (moyenne >= 18) {
        appreciation = "Excellent";
    } else if (moyenne >= 16) {
        appreciation = "Très bien";
    } else if (moyenne >= 14) {
        appreciation = "Bien";
    } else if (moyenne >= 12) {
        appreciation = "Assez bien";
    } else if (moyenne >= 10) {
        appreciation = "Passable";
    } else {
        appreciation = "Insuffisant";
    }

    document.getElementById("zone_moyenne").innerHTML = "Moyenne calculée : " + moyenne + " / 20 - " + appreciation;
}
</script>

</body>
</html>
